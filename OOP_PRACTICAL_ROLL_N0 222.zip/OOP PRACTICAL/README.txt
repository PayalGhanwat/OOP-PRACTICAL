OOP PRACTICAL FOLDER
====================

This folder contains 8 Java practicals and sample outputs.

Practical No 1 - Complex number addition, subtraction and multiplication
File: Practical No 1/Complex1.java

Practical No 2 - Publication, Book and Magazine using inheritance
File: Practical No 2/Main.java (package oop)

Practical No 3 - Employee salary slips using inheritance
File: Practical No 3/Ass3.java (package oop)

Practical No 4 - Abstract class and area of triangle/rectangle
File: Practical No 4/ShapeDemo.java (package oop)

Practical No 5 - Vehicle interface implemented by Bicycle, Car and Bike
File: Practical No 5/Ass5.java (package oop)

Practical No 6 - Exception handling
File: Practical No 6/ExceptionHandlingDemo.java

Practical No 7 - Generic method to count even, odd, prime and palindrome numbers
File: Practical No 7/Ass7.java (package oop)

Practical No 8 - Student database using file handling and serialization
File: Practical No 8/StudentDatabase.java

RUNNING JAVA FILES
------------------
For files without package declaration:
  javac FileName.java
  java ClassName

For files with "package oop;":
  Place the .java file inside a folder named oop, compile from the parent folder:
  javac oop/FileName.java
  java oop.ClassName

Each practical is separated into its own folder to avoid class-name conflicts.
Sample outputs are in OUTPUTS.txt. Interactive outputs depend on the values entered.
