import java.util.Scanner;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter first number: ");
            int num1 = Integer.parseInt(sc.nextLine());
            System.out.print("Enter second number: ");
            int num2 = Integer.parseInt(sc.nextLine());
            System.out.println("Division result = " + (num1 / num2));
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter valid integer numbers.");
        } finally {
            System.out.println("Division operation completed.");
        }

        try {
            int[] arr = {10, 20, 30};
            System.out.println("Array element: " + arr[5]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Array index is out of bounds.");
        }
        sc.close();
    }
}
