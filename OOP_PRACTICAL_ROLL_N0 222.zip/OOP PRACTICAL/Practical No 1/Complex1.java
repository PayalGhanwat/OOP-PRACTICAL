import java.util.Scanner;

public class Complex1 {
    double real, imaginary;

    Complex1() { real = 0; imaginary = 0; }
    Complex1(double r, double i) { real = r; imaginary = i; }

    Complex1 add(Complex1 c) {
        return new Complex1(real + c.real, imaginary + c.imaginary);
    }

    Complex1 subtract(Complex1 c) {
        return new Complex1(real - c.real, imaginary - c.imaginary);
    }

    Complex1 multiply(Complex1 c) {
        return new Complex1(real * c.real - imaginary * c.imaginary,
                            real * c.imaginary + imaginary * c.real);
    }

    void display() {
        if (imaginary >= 0) System.out.println(real + " + " + imaginary + "i");
        else System.out.println(real + " - " + (-imaginary) + "i");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Real and Imaginary part of First Complex Number:");
        double r1 = sc.nextDouble(), i1 = sc.nextDouble();
        System.out.println("Enter Real and Imaginary part of Second Complex Number:");
        double r2 = sc.nextDouble(), i2 = sc.nextDouble();

        Complex1 c1 = new Complex1(r1, i1), c2 = new Complex1(r2, i2);
        System.out.print("\nFirst Complex Number: "); c1.display();
        System.out.print("Second Complex Number: "); c2.display();
        System.out.print("Addition: "); c1.add(c2).display();
        System.out.print("Subtraction: "); c1.subtract(c2).display();
        System.out.print("Multiplication: "); c1.multiply(c2).display();
        sc.close();
    }
}
