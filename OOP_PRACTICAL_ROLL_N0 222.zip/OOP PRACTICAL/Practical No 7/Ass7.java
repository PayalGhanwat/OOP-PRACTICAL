package oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Ass7 {
    public static <T> int countElements(List<T> list, Predicate<T> condition) {
        int count = 0;
        for (T element : list) if (condition.test(element)) count++;
        return count;
    }

    public static boolean isPrime(Integer n) {
        if (n < 2) return false;
        for (int i = 2; i <= n / i; i++) if (n % i == 0) return false;
        return true;
    }

    public static boolean isPalindrome(Integer n) {
        if (n < 0) return false;
        int original = n, reverse = 0;
        while (n > 0) { reverse = reverse * 10 + n % 10; n /= 10; }
        return original == reverse;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> numbers = new ArrayList<>();
        System.out.print("Enter number of elements: ");
        int size = sc.nextInt();
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) numbers.add(sc.nextInt());

        System.out.println("\nNumbers: " + numbers);
        System.out.println("Even numbers count: " + countElements(numbers, n -> n % 2 == 0));
        System.out.println("Odd numbers count: " + countElements(numbers, n -> n % 2 != 0));
        System.out.println("Prime numbers count: " + countElements(numbers, Ass7::isPrime));
        System.out.println("Palindrome numbers count: " + countElements(numbers, Ass7::isPalindrome));
        sc.close();
    }
}
