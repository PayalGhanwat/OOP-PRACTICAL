import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentDatabase {
    private static final String FILE_NAME = "students.dat";
    private static final Scanner sc = new Scanner(System.in);

    static class Student implements Serializable {
        private static final long serialVersionUID = 1L;
        String studentId, name, rollNo, studentClass, address;
        double marks;

        Student(String studentId, String name, String rollNo, String studentClass, double marks, String address) {
            this.studentId = studentId; this.name = name; this.rollNo = rollNo;
            this.studentClass = studentClass; this.marks = marks; this.address = address;
        }
        void display() {
            System.out.println("----------------------------");
            System.out.println("Student ID : " + studentId);
            System.out.println("Name       : " + name);
            System.out.println("Roll No    : " + rollNo);
            System.out.println("Class      : " + studentClass);
            System.out.println("Marks      : " + marks);
            System.out.println("Address    : " + address);
        }
    }

    @SuppressWarnings("unchecked")
    static ArrayList<Student> readRecords() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (ArrayList<Student>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading database: " + e.getMessage());
            return null;
        }
    }

    static boolean saveRecords(ArrayList<Student> students) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(students);
            return true;
        } catch (IOException e) {
            System.out.println("Error saving database: " + e.getMessage());
            return false;
        }
    }

    static String readText(String message) {
        while (true) {
            System.out.print(message);
            String value = sc.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("Input cannot be empty.");
        }
    }

    static int readInt(String message) {
        while (true) {
            System.out.print(message);
            try { return Integer.parseInt(sc.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Enter a valid integer."); }
        }
    }

    static double readMarks() {
        while (true) {
            System.out.print("Enter Marks (0-100): ");
            try {
                double marks = Double.parseDouble(sc.nextLine().trim());
                if (Double.isFinite(marks) && marks >= 0 && marks <= 100) return marks;
            } catch (NumberFormatException e) { /* handled below */ }
            System.out.println("Enter a valid mark between 0 and 100.");
        }
    }

    static int findStudent(ArrayList<Student> students, String id) {
        for (int i = 0; i < students.size(); i++)
            if (students.get(i).studentId.equalsIgnoreCase(id)) return i;
        return -1;
    }

    static Student inputStudent(String id) {
        String name = readText("Enter Name: ");
        String roll = readText("Enter Roll Number: ");
        String cls = readText("Enter Class: ");
        double marks = readMarks();
        String address = readText("Enter Address: ");
        return new Student(id, name, roll, cls, marks, address);
    }

    static void createDatabase() {
        int n = readInt("Enter number of students: ");
        if (n < 0) { System.out.println("Number of students cannot be negative."); return; }
        ArrayList<Student> students = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.println("\nStudent " + (i + 1));
            String id;
            while (true) {
                id = readText("Enter Student ID: ");
                if (findStudent(students, id) == -1) break;
                System.out.println("Student ID already exists. Enter another ID.");
            }
            students.add(inputStudent(id));
        }
        if (saveRecords(students)) System.out.println("Database created successfully.");
    }

    static void displayDatabase() {
        ArrayList<Student> students = readRecords();
        if (students == null) return;
        if (students.isEmpty()) { System.out.println("Database is empty."); return; }
        for (Student s : students) s.display();
    }

    static void deleteRecord() {
        ArrayList<Student> students = readRecords();
        if (students == null) return;
        String id = readText("Enter Student ID to delete: ");
        int index = findStudent(students, id);
        if (index == -1) { System.out.println("Student record not found."); return; }
        students.remove(index);
        if (saveRecords(students)) System.out.println("Record deleted successfully.");
    }

    static void updateRecord() {
        ArrayList<Student> students = readRecords();
        if (students == null) return;
        String id = readText("Enter Student ID to update: ");
        int index = findStudent(students, id);
        if (index == -1) { System.out.println("Student record not found."); return; }
        System.out.println("Enter updated details:");
        students.set(index, inputStudent(id));
        if (saveRecords(students)) System.out.println("Record updated successfully.");
    }

    static void searchRecord() {
        ArrayList<Student> students = readRecords();
        if (students == null) return;
        String id = readText("Enter Student ID to search: ");
        int index = findStudent(students, id);
        if (index == -1) System.out.println("Student record not found.");
        else { System.out.println("Student record found:"); students.get(index).display(); }
    }

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n=== STUDENT DATABASE ===");
            System.out.println("1. Create Database");
            System.out.println("2. Display Database");
            System.out.println("3. Delete Record");
            System.out.println("4. Update Record");
            System.out.println("5. Search Record");
            System.out.println("6. Exit");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: createDatabase(); break;
                case 2: displayDatabase(); break;
                case 3: deleteRecord(); break;
                case 4: updateRecord(); break;
                case 5: searchRecord(); break;
                case 6: System.out.println("Exiting program."); break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 6);
        sc.close();
    }
}
